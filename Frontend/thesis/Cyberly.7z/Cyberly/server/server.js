// server.js

// BASE SETUP
// =============================================================================

// call the packages we need
var express    = require('express');        // call express
var app        = express();                 // define our app using express
var bodyParser = require('body-parser');
var mongoose   = require('mongoose');

// Here we find an appropriate database to connect to, defaulting to
// localhost if we don't find one.
var uristring = 'mongodb://cyberly_user:markella1@ds149431.mlab.com:49431/heroku_l1ghb699' ||'mongodb://localhost:27017/cyberly_db';

// Makes connection asynchronously.  Mongoose will queue up database
// operations and release them when the connection is complete.
mongoose.connect(uristring, function (err, res) {

 	if (err) {
     	console.log ('ERROR connecting to: ' + uristring + '. ' + err);
    } else {
      	console.log ('Succeeded connected to: ' + uristring);
   }
});

 // mongoose.connect('mongodb://localhost:27017/cyberly_db')

var Fingerprint = require('./app/models/fingerprint'); 
var System32 = require('./app/models/system32')

// configure app to use bodyParser()
// this will let us get the data from a POST
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


var port = process.env.PORT || 8080;   
// var port = process.env.PORT || 3000;        // set our port

// ROUTES FOR OUR API
// =============================================================================
var router = express.Router();              // get an instance of the express Router

// middleware to use for all requests
router.use(function(req, res, next) {
    // do logging
    console.log('Something is happening.');
    next(); // make sure we go to the next routes and don't stop here
});

// test route to make sure everything is working (accessed at GET http://localhost:8080/api)
router.get('/', function(req, res) {
    res.json({ message: 'hooray! welcome to our api!' });   
});




// on routes that end in /fingerprints
// ----------------------------------------------------
router.route('/fingerprints')

    // create a bear (accessed at POST http://localhost:8080/api/fingerprints)
    .post(function(req, res) {

	    for(var i = 0; i < req.body.fingerprints.length; i++) {
	            
	       	var fingerprint = new Fingerprint();      // create a new instance of the Fingerprint model
	        // fingerprint.uuid = req.body.uuid;  // set the uuid
	        // fingerprint.parentName = req.body.fingerprints[i].parentName;//set the parentName
	        // fingerprint.filename = req.body.fingerprints[i].filename;  // set the fingerprint filename
	        // fingerprint.md5 = req.body.fingerprints[i].md5;  // set the md5
	        	        
	       	var query = {'uuid':req.body.uuid, 'filename':req.body.fingerprints[i].filename};
	       	var update = {'uuid':req.body.uuid, 'filename':req.body.fingerprints[i].filename, 'md5':req.body.fingerprints[i].md5, 'parentName': req.body.fingerprints[i].parentName};

	   		Fingerprint.findOneAndUpdate(query, update, {upsert:true, returnOriginal:false}, function(err, doc) {
	    	
	    		if (err) 
	   				return res.send(500, { error: err });

	    		return res.send("succesfully saved");
			});

	    }
	});




// second post request  for system32 in order for a second diagram to be created 
router.route('/system32')

    // create a system32 (accessed at POST http://localhost:8080/api/system32)
    .post(function(req, res) {
        
        
        for(var i = 0; i < req.body.fingerprints.length; i++) {
            
            var system32 = new System32();       // create a new instance of the System32 model
            
            // system32.uuid = req.body.uuid;  // set the uuid
            // system32.parentName = req.body.fingerprints[i].parentName;//set the parentName
            // system32.filename = req.body.fingerprints[i].filename;  // set the fingerprint filename(fingerprints is the same because i want also fingerprints in system32 folder)
            // system32.md5 = req.body.fingerprints[i].md5;  // set the md5
            
            var query = {'uuid':req.body.uuid, 'filename':req.body.fingerprints[i].filename};
	       	var update = {'uuid':req.body.uuid, 'filename':req.body.fingerprints[i].filename, 'md5':req.body.fingerprints[i].md5, 'parentName': req.body.fingerprints[i].parentName};

            // save the system32 and check for errors
          	System32.findOneAndUpdate(query, update, {upsert:true,returnOriginal:false}, function(err, doc) {
    	
    			if (err) 
   					return res.send(500, { error: err });
    
    			return res.send("succesfully saved");
			});
    	}
	});
 

// REGISTER OUR ROUTES -------------------------------
// all of our routes will be prefixed with /api
app.use('/api', router);

// START THE SERVER
// =============================================================================
app.listen(port);
console.log('Magic happens on port ' + port);







